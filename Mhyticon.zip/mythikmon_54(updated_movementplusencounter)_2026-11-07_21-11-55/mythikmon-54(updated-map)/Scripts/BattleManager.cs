#nullable enable
using Godot;
using System;
using System.Threading.Tasks;

namespace Mythikmon;

// Runs battles using your existing BattleUI.tscn.
// Does not draw a map, player, or main menu.
public partial class BattleManager : Node
{
    [Export] public CharacterBody2D? PlayerCharacter { get; set; }
    [Export] public BattleUI? BattleUiNode { get; set; }

    private readonly Random random = new();
    private PlayerData saveData = new();
    private Creature? myCreature;
    private Creature? wildCreature;
    private WildEncounter? currentEncounter;
    private Texture2D? myTexture;
    private Texture2D? wildTexture;
    private bool busy;
    private bool outro;

    public bool IsInBattle => wildCreature != null;

    public override void _Ready()
    {
        saveData = PlayerData.Load();
        myCreature = new TikbalangCreature(5); // Starter creature for testing.

        if (PlayerCharacter == null || BattleUiNode == null)
        {
            GD.PushError("BattleManager: assign Player Character and Battle Ui Node in the Inspector.");
            return;
        }

        BattleUiNode.AttackPressed += Attack;
        BattleUiNode.TalismanPressed += UseTalisman;
        BattleUiNode.RunPressed += RunAway;
        BattleUiNode.SetActive(false);
    }

    public override void _ExitTree()
    {
        if (BattleUiNode != null && GodotObject.IsInstanceValid(BattleUiNode))
        {
            BattleUiNode.AttackPressed -= Attack;
            BattleUiNode.TalismanPressed -= UseTalisman;
            BattleUiNode.RunPressed -= RunAway;
        }
    }

    public void StartEncounter(WildEncounter encounter)
    {
        if (IsInBattle || busy || PlayerCharacter == null || BattleUiNode == null)
            return;

        currentEncounter = encounter;
        wildCreature = CreateWildCreature(encounter.CreatureName);

        if (myCreature == null)
            myCreature = new TikbalangCreature(5);

        if (myCreature.IsFainted())
            myCreature.Heal();

        myTexture = LoadCreatureTexture(myCreature);
        wildTexture = LoadCreatureTexture(wildCreature);

        // Freeze only the existing player's movement script; keep its scene/camera.
        PlayerCharacter.Velocity = Vector2.Zero;
        PlayerCharacter.SetPhysicsProcess(false);

        // Block the menu while the intro animation plays.
        busy = true;
        PlayIntro();
    }

    private async void PlayIntro()
    {
        var ui = BattleUiNode;
        var enemy = wildCreature;
        if (ui == null || enemy == null)
        {
            busy = false;
            return;
        }

        await ui.PlayIntroAsync(() =>
        {
            ui.BeginBattle();
            ui.SetActive(true);
            UpdateBattle("");
        });

        UpdateBattle($"A wild {enemy.Name} appeared!");
        busy = false;
    }

    private Creature CreateWildCreature(string name)
    {
        if (name.Equals("Random", StringComparison.OrdinalIgnoreCase))
        {
            string[] names = { "Tikbalang", "Manananggal", "Bakunawa", "Kapre", "Sigbin" };
            name = names[random.Next(names.Length)];
        }

        return name.ToLowerInvariant() switch
        {
            "tikbalang" => new TikbalangCreature(),
            "manananggal" => new ManananggalCreature(),
            "bakunawa" => new BakunawaCreature(),
            "kapre" => new KapreCreature(),
            "sigbin" => new SigbinCreature(),
            _ => new TikbalangCreature()
        };
    }

    private static Texture2D? LoadCreatureTexture(Creature creature)
    {
        return ResourceLoader.Exists(creature.SpritePath)
            ? GD.Load<Texture2D>(creature.SpritePath)
            : null;
    }

    private void UpdateBattle(string message, bool animateBars = false)
    {
        if (BattleUiNode == null)
            return;

        BattleUiNode.Refresh(
            wildCreature, wildTexture,
            myCreature, myTexture,
            message, saveData.Talismans, animateBars);
    }

    private async void Attack()
    {
        if (busy || outro || wildCreature == null || myCreature == null || BattleUiNode == null)
            return;

        busy = true;
        Creature enemy = wildCreature;
        Creature mine = myCreature;
        int damage = Mathf.Max(1, mine.CalculateDamage() - enemy.Defense / 3);
        bool enemyWillFaint = enemy.HP <= damage;
        UpdateBattle($"{mine.Name} used {mine.GetSpecialMove()}!");

        await BattleUiNode.PlayAttackAsync(true, () =>
        {
            enemy.TakeDamage(damage);
            UpdateBattle($"You dealt {damage} damage!", true);
        }, enemyWillFaint);

        if (enemy.IsFainted())
        {
            UpdateBattle($"You defeated the wild {enemy.Name}!");
            await Pause(0.8);
            EndBattle(removeEncounter: true);
        }
        else
        {
            await EnemyTurn();
        }

        busy = false;
    }

    private async void UseTalisman()
    {
        if (busy || outro || wildCreature == null || BattleUiNode == null)
            return;

        if (saveData.Talismans <= 0)
        {
            UpdateBattle("You have no talismans left!");
            return;
        }

        busy = true;
        Creature enemy = wildCreature;
        saveData.Talismans--;

        // A weakened enemy is easier to capture (maximum chance: 95%).
        int missingHp = enemy.MaxHP - enemy.HP;
        int captureChance = Mathf.Min(95, 35 + missingHp * 100 / enemy.MaxHP);
        bool captured = random.Next(100) < captureChance;

        if (captured)
        {
            saveData.CapturedCreatureNames.Add(enemy.Name);
            saveData.Save();
            UpdateBattle($"{enemy.Name} was captured with a talisman!");
            await Pause(0.9);
            EndBattle(removeEncounter: true);
        }
        else
        {
            saveData.Save();
            UpdateBattle("The talisman failed! The wild Mythikmon broke free!");
            await Pause(0.4);
            await EnemyTurn();
        }

        busy = false;
    }

    private async Task EnemyTurn()
    {
        if (wildCreature == null || myCreature == null || BattleUiNode == null)
            return;

        Creature enemy = wildCreature;
        Creature mine = myCreature;
        int damage = Mathf.Max(1, enemy.CalculateDamage() - mine.Defense / 3);
        bool mineWillFaint = mine.HP <= damage;
        UpdateBattle($"Wild {enemy.Name} attacks!");

        await BattleUiNode.PlayAttackAsync(false, () =>
        {
            mine.TakeDamage(damage);
            UpdateBattle($"Wild {enemy.Name} dealt {damage} damage!", true);
        }, mineWillFaint);

        if (mine.IsFainted())
        {
            UpdateBattle($"{mine.Name} fainted! Returning to the map.");
            await Pause(0.8);
            mine.Heal(); // Simple recovery for this first version.
            EndBattle(removeEncounter: false);
        }
    }

    private void RunAway()
    {
        if (busy || outro || !IsInBattle)
            return;

        EndBattle(removeEncounter: false);
    }

    private async void EndBattle(bool removeEncounter)
    {
        if (outro)
            return;

        outro = true;

        // Circle wipe: screen goes black, the battle screen is hidden, then the map is revealed.
        var ui = BattleUiNode;
        if (ui != null)
            await ui.PlayOutroAsync(() => ui.SetActive(false));

        if (PlayerCharacter != null)
        {
            PlayerCharacter.Velocity = Vector2.Zero;
            PlayerCharacter.SetPhysicsProcess(true);
        }

        if (removeEncounter && currentEncounter != null && currentEncounter.RemoveAfterWin)
            currentEncounter.QueueFree();

        wildCreature = null;
        currentEncounter = null;
        wildTexture = null;
        outro = false;
    }

    private async Task Pause(double seconds)
    {
        await ToSignal(GetTree().CreateTimer(seconds), SceneTreeTimer.SignalName.Timeout);
    }
}
