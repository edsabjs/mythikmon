#nullable enable
using Godot;

namespace Mythikmon;

// Full-screen battle backdrop that sits behind the creatures and panels.
// If Texture is set it draws that image; otherwise it draws a simple grass field.
public partial class BattleBackground : Control
{
	public Texture2D? Texture { get; set; }
	public Vector2 EnemyHome { get; set; } = new Vector2(720, 240);
	public Vector2 PlayerHome { get; set; } = new Vector2(215, 380);

	public override void _Ready()
	{
		MouseFilter = MouseFilterEnum.Ignore;
		SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
		Resized += QueueRedraw;
	}

	public override void _Draw()
	{
		float w = Size.X, h = Size.Y;
		if (w <= 0 || h <= 0) return;

		if (Texture != null)
		{
			DrawTextureRect(Texture, new Rect2(0, 0, w, h), false);
		}
		else
		{
			float horizon = h * 0.36f;

			// Sky
			VGradient(0, horizon, w, new Color(0.40f, 0.68f, 0.93f), new Color(0.78f, 0.91f, 0.98f));

			// Clouds
			var cloud = new Color(1, 1, 1, 0.85f);
			Ellipse(new Vector2(w * 0.18f, h * 0.10f), 60, 14, cloud);
			Ellipse(new Vector2(w * 0.24f, h * 0.085f), 40, 12, cloud);
			Ellipse(new Vector2(w * 0.70f, h * 0.16f), 70, 15, cloud);
			Ellipse(new Vector2(w * 0.76f, h * 0.14f), 45, 12, cloud);

			// Far hills
			Hills(w, horizon, 26f, 0.010f, 0.5f, new Color(0.45f, 0.70f, 0.52f));
			// Near hills
			Hills(w, horizon, 12f, 0.017f, 2.0f, new Color(0.34f, 0.62f, 0.38f));

			// Grass field
			VGradient(horizon, h, w, new Color(0.47f, 0.78f, 0.38f), new Color(0.30f, 0.60f, 0.30f));
			for (float y = horizon + 20; y < h; y += 28)
				DrawRect(new Rect2(0, y, w, 12), new Color(0, 0, 0, 0.05f));
		}

		// Ground circles under each creature
		Platform(EnemyHome, 130, 30);
		Platform(PlayerHome, 170, 38);
	}

	private void Platform(Vector2 feet, float rx, float ry)
	{
		Ellipse(feet + new Vector2(0, 8), rx, ry, new Color(0.18f, 0.35f, 0.18f));        // thickness
		Ellipse(feet, rx, ry, new Color(0.62f, 0.86f, 0.46f));                            // top
		Ellipse(feet, rx * 0.82f, ry * 0.78f, new Color(0.70f, 0.92f, 0.52f));            // highlight
	}

	private void VGradient(float y0, float y1, float w, Color top, Color bottom)
	{
		DrawPolygon(
			new[] { new Vector2(0, y0), new Vector2(w, y0), new Vector2(w, y1), new Vector2(0, y1) },
			new[] { top, top, bottom, bottom });
	}

	private void Hills(float w, float horizon, float amp, float freq, float phase, Color color)
	{
		var pts = new System.Collections.Generic.List<Vector2>();
		for (float x = 0; x <= w + 16; x += 16)
			pts.Add(new Vector2(x, horizon - amp - amp * 0.6f * Mathf.Sin(x * freq + phase)));
		pts.Add(new Vector2(w + 16, horizon + 4));
		pts.Add(new Vector2(0, horizon + 4));
		DrawColoredPolygon(pts.ToArray(), color);
	}

	private void Ellipse(Vector2 c, float rx, float ry, Color color)
	{
		const int n = 40;
		var pts = new Vector2[n];
		for (int i = 0; i < n; i++)
		{
			float a = Mathf.Tau * i / n;
			pts[i] = c + new Vector2(Mathf.Cos(a) * rx, Mathf.Sin(a) * ry);
		}
		DrawColoredPolygon(pts, color);
	}
}
