#nullable enable
using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mythikmon;

// Battle manager only. Does NOT create a player, main menu, map, or camera.
// Attach to your existing "Game" Node2D in entire_map3.tscn.
public partial class Game : Node2D
{
	[Export] public CharacterBody2D? PlayerCharacter { get; set; }

	private readonly Random random = new();
	private readonly List<Creature> party = new();
	private readonly List<Creature> wildPool = new();
	private readonly Dictionary<string, Texture2D> creatureTextures = new();

	private PlayerData saveData = new();
	private Creature? activeCreature;
	private Creature? wildCreature;
	private Creature? lastEnemy;
	private BattleUI battleUi = null!;
	private CanvasLayer battleLayer = null!;
	private ColorRect battleShade = null!;

	private bool isBattling;
	private bool busy;
	private bool battleResolved;
	private bool removeEncounterAfterBattle;
	private bool playerWasProcessingPhysics = true;
	private string battleMessage = "";

	// true means the world creature was captured or defeated; false means it escaped.
	public event Action<bool>? EncounterEnded;
	public bool IsBattling => isBattling;

	public override void _Ready()
	{
		AddToGroup("battle_manager");

		// Reuse the creature classes you already made.
		wildPool.Add(new TikbalangCreature());
		wildPool.Add(new ManananggalCreature());
		wildPool.Add(new BakunawaCreature());
		wildPool.Add(new KapreCreature());
		wildPool.Add(new SigbinCreature());

		foreach (Creature creature in wildPool)
		{
			if (ResourceLoader.Exists(creature.SpritePath))
				creatureTextures[creature.Name] = GD.Load<Texture2D>(creature.SpritePath);
		}

		saveData = PlayerData.Load();
		party.Add(new TikbalangCreature(5)); // Starting Mythikmon (change if desired)

		// Restore previously captured creature types into the battle party.
		foreach (string creatureName in saveData.CapturedCreatureNames)
		{
			Creature? template = wildPool.FirstOrDefault(c =>
				c.Name.Equals(creatureName, StringComparison.OrdinalIgnoreCase));
			if (template != null)
				party.Add(Clone(template));
		}
		activeCreature = party[0];

		// Reuse your existing Player scene instead of spawning another player.
		PlayerCharacter ??= GetTree().CurrentScene?.FindChild("Player", true, false)
			as CharacterBody2D;
		if (PlayerCharacter == null)
			GD.PushWarning("Game: Player not found. Drag your Player node into the Player Character property in the Inspector.");

		const string battleUiPath = "res://Scenes/BattleUI.tscn";
		if (!ResourceLoader.Exists(battleUiPath))
		{
			GD.PushError($"Battle UI scene is missing: {battleUiPath}");
			return;
		}

		// CanvasLayer keeps the battle buttons on screen while Camera2D moves.
		battleLayer = new CanvasLayer { Layer = 20 };
		AddChild(battleLayer);

		battleShade = new ColorRect
		{
			Color = new Color(0.04f, 0.09f, 0.14f, 0.86f),
			MouseFilter = Control.MouseFilterEnum.Ignore,
			Visible = false
		};
		battleLayer.AddChild(battleShade);
		battleShade.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

		battleUi = GD.Load<PackedScene>(battleUiPath).Instantiate<BattleUI>();
		battleLayer.AddChild(battleUi);
		battleUi.SetActive(false);
		battleUi.AttackPressed += Attack;
		battleUi.TalismanPressed += UseTalisman;
		battleUi.RunPressed += RunFromBattle;
	}

	// Called by WildEncounter.cs when the player touches a creature.
	public bool TryStartEncounter(string creatureName)
	{
		if (isBattling || !IsInstanceValid(battleUi))
			return false;

		Creature? template = wildPool.FirstOrDefault(c =>
			c.Name.Equals(creatureName, StringComparison.OrdinalIgnoreCase));
		if (template == null)
		{
			GD.PushWarning($"Unknown Mythikmon: {creatureName}");
			return false;
		}

		wildCreature = Clone(template);
		lastEnemy = wildCreature;
		battleResolved = false;
		removeEncounterAfterBattle = false;
		busy = false;
		isBattling = true;

		if (PlayerCharacter != null)
		{
			playerWasProcessingPhysics = PlayerCharacter.IsPhysicsProcessing();
			PlayerCharacter.Velocity = Vector2.Zero;
			PlayerCharacter.SetPhysicsProcess(false);
			PlayerCharacter.GetNodeOrNull<AnimatedSprite2D>("AnimatedSprite2D")?.Stop();
		}

		battleShade.Visible = true;
		battleUi.BeginBattle();
		battleMessage = $"A wild {wildCreature.Name} appeared!";
		RefreshBattle(false);
		return true;
	}

	private void RefreshBattle(bool animate)
	{
		battleUi.SetActive(isBattling);
		if (!isBattling) return;

		if (wildCreature != null)
			lastEnemy = wildCreature;

		creatureTextures.TryGetValue(lastEnemy?.Name ?? "", out Texture2D? enemyTexture);
		creatureTextures.TryGetValue(activeCreature?.Name ?? "", out Texture2D? allyTexture);
		battleUi.Refresh(lastEnemy, enemyTexture, activeCreature, allyTexture,
			battleMessage, saveData.Talismans, animate);
	}

	private static Creature Clone(Creature creature) => creature.Name switch
	{
		"Tikbalang" => new TikbalangCreature(creature.Level),
		"Manananggal" => new ManananggalCreature(creature.Level),
		"Bakunawa" => new BakunawaCreature(creature.Level),
		"Kapre" => new KapreCreature(creature.Level),
		"Sigbin" => new SigbinCreature(creature.Level),
		_ => new TikbalangCreature(creature.Level)
	};

	private async void Attack()
	{
		if (!isBattling || busy || battleResolved ||
			wildCreature == null || activeCreature == null)
			return;

		busy = true;
		Creature foe = wildCreature;
		Creature ally = activeCreature;

		int damage = Mathf.Max(1, ally.CalculateDamage() - foe.Defense / 3);
		bool foeWillFaint = foe.HP - damage <= 0;

		battleMessage = $"{ally.Name} used {ally.GetSpecialMove()}!";
		RefreshBattle(false);
		await battleUi.PlayAttackAsync(true, () =>
		{
			foe.TakeDamage(damage);
			RefreshBattle(true);
		}, foeWillFaint);

		if (foe.IsFainted())
		{
			battleResolved = true;
			removeEncounterAfterBattle = true;
			battleMessage = $"You defeated {foe.Name}! Press Enter to continue.";
			RefreshBattle(false);
			busy = false;
			return;
		}

		await ToSignal(GetTree().CreateTimer(0.3), SceneTreeTimer.SignalName.Timeout);
		await EnemyAttack(foe, ally, $"You dealt {damage} damage.");
		busy = false;
	}

	private async Task EnemyAttack(Creature foe, Creature ally, string previousMessage)
	{
		int damage = Mathf.Max(1, foe.CalculateDamage() - ally.Defense / 3);
		bool allyWillFaint = ally.HP - damage <= 0;

		battleMessage = $"{foe.Name} attacks!";
		RefreshBattle(false);
		await battleUi.PlayAttackAsync(false, () =>
		{
			ally.TakeDamage(damage);
			battleMessage = $"{previousMessage} {foe.Name} dealt {damage} damage!";
			RefreshBattle(true);
		}, allyWillFaint);

		if (ally.IsFainted())
		{
			ally.Heal(); // Simple demo behavior; change when you add a party menu.
			battleResolved = true;
			battleMessage = "Your Mythikmon recovered. Press Enter to return to the map.";
			removeEncounterAfterBattle = false;
			RefreshBattle(false);
		}
	}

	private async void UseTalisman()
	{
		if (!isBattling || busy || battleResolved || wildCreature == null)
			return;

		if (saveData.Talismans <= 0)
		{
			battleMessage = "You have no talismans left!";
			RefreshBattle(false);
			return;
		}

		busy = true;
		Creature foe = wildCreature;
		saveData.Talismans--;
		SaveProgress();

		// The weaker the wild creature, the easier it is to capture.
		int chance = Mathf.Clamp(
			35 + (foe.MaxHP - foe.HP) * 100 / Mathf.Max(1, foe.MaxHP),
			5, 95);

		if (random.Next(100) < chance)
		{
			party.Add(Clone(foe));
			saveData.CapturedCreatureNames.Add(foe.Name);
			SaveProgress();
			battleResolved = true;
			removeEncounterAfterBattle = true;
			battleMessage = $"You captured {foe.Name}! Press Enter to continue.";
			wildCreature = null;
			RefreshBattle(true);
			busy = false;
			return;
		}

		battleMessage = $"{foe.Name} broke free from the talisman!";
		RefreshBattle(false);
		await ToSignal(GetTree().CreateTimer(0.4), SceneTreeTimer.SignalName.Timeout);

		if (activeCreature != null)
			await EnemyAttack(foe, activeCreature, "The talisman failed.");
		busy = false;
	}

	private void RunFromBattle()
	{
		if (!isBattling || busy) return;
		removeEncounterAfterBattle = false;
		EndBattle();
	}

	private void EndBattle()
	{
		if (!isBattling) return;
		isBattling = false;
		battleShade.Visible = false;
		battleUi.SetActive(false);
		wildCreature = null;
		lastEnemy = null;
		busy = false;

		if (PlayerCharacter != null)
		{
			PlayerCharacter.Velocity = Vector2.Zero;
			PlayerCharacter.SetPhysicsProcess(playerWasProcessingPhysics);
		}

		EncounterEnded?.Invoke(removeEncounterAfterBattle);
	}

	private void SaveProgress()
	{
		if (PlayerCharacter != null)
			saveData.Position = PlayerCharacter.GlobalPosition;
		saveData.Save();
	}

	public override void _UnhandledInput(InputEvent e)
	{
		if (!isBattling || e is not InputEventKey key || !key.Pressed || key.Echo)
			return;

		if (key.Keycode == Key.Enter && !busy && battleResolved)
		{
			EndBattle();
			GetViewport().SetInputAsHandled();
		}
		else if (key.Keycode == Key.Key1)
		{
			Attack();
			GetViewport().SetInputAsHandled();
		}
		else if (key.Keycode == Key.Key2)
		{
			UseTalisman();
			GetViewport().SetInputAsHandled();
		}
		else if (key.Keycode == Key.Key3 || key.Keycode == Key.Escape)
		{
			RunFromBattle();
			GetViewport().SetInputAsHandled();
		}
	}
}
