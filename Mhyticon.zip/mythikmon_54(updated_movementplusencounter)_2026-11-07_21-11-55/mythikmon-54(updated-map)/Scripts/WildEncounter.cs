#nullable enable
using Godot;

namespace Mythikmon;

public partial class WildEncounter : Area2D
{
	[Export] public BattleManager? Manager { get; set; }

	// The TileMapLayer that contains the bushes (Thingys/Foliage).
	[Export] public TileMapLayer? GrassLayer { get; set; }

	// Atlas coordinates of the bush tile (source 0). The flowers are other tiles.
	[Export] public Vector2I GrassAtlasCoords { get; set; } = new Vector2I(3, 2);

	// If true, ANY tile on the GrassLayer (bushes and flowers) triggers encounters.
	[Export] public bool AnyTileCounts { get; set; } = false;

	// Where the player's feet are, relative to the Player node.
	[Export] public Vector2 FootOffset { get; set; } = new Vector2(0, 20);

	[Export] public string CreatureName { get; set; } = "Random";

	[Export] public bool RemoveAfterWin { get; set; } = false;

	[Export(PropertyHint.Range, "1,100,1")]
	public int EncounterChance { get; set; } = 15;

	[Export(PropertyHint.Range, "8,128,1")]
	public float PixelsPerCheck { get; set; } = 32f;

	private bool playerInside = false; // only used if GrassLayer is not set
	private bool wasInBattle = false;

	private Vector2 lastPosition;
	private float distanceWalked = 0f;
	private float cooldown = 0f;

	public override void _Ready()
	{
		BodyEntered += OnBodyEntered;
		BodyExited += OnBodyExited;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (Manager == null || body != Manager.PlayerCharacter)
			return;

		playerInside = true;
		lastPosition = body.GlobalPosition;
		distanceWalked = 0f;
	}

	private void OnBodyExited(Node2D body)
	{
		if (Manager == null || body != Manager.PlayerCharacter)
			return;

		playerInside = false;
		distanceWalked = 0f;
	}

	private bool IsPlayerInGrass(Node2D player)
	{
		if (GrassLayer == null)
			return playerInside;

		Vector2 feet = player.GlobalPosition + FootOffset;
		Vector2I cell = GrassLayer.LocalToMap(GrassLayer.ToLocal(feet));

		if (GrassLayer.GetCellSourceId(cell) == -1)
			return false;

		return AnyTileCounts || GrassLayer.GetCellAtlasCoords(cell) == GrassAtlasCoords;
	}

	public override void _PhysicsProcess(double delta)
	{
		if (Manager?.PlayerCharacter == null)
			return;

		var player = Manager.PlayerCharacter;

		// Don't trigger encounters during battle.
		if (Manager.IsInBattle)
		{
			wasInBattle = true;
			lastPosition = player.GlobalPosition;
			return;
		}

		// Short cooldown after a battle ends.
		if (wasInBattle)
		{
			wasInBattle = false;
			cooldown = 2f;
			distanceWalked = 0f;
			lastPosition = player.GlobalPosition;
		}

		float moved = player.GlobalPosition.DistanceTo(lastPosition);
		lastPosition = player.GlobalPosition;

		if (!IsPlayerInGrass(player))
		{
			distanceWalked = 0f;
			return;
		}

		if (cooldown > 0f)
		{
			cooldown = Mathf.Max(0f, cooldown - (float)delta);
			return;
		}

		// Count how far the player actually walks while standing in grass.
		distanceWalked += moved;

		if (distanceWalked >= PixelsPerCheck)
		{
			distanceWalked -= PixelsPerCheck;

			if (GD.Randf() * 100f < EncounterChance)
			{
				distanceWalked = 0f;
				Manager.StartEncounter(this);
			}
		}
	}
}
