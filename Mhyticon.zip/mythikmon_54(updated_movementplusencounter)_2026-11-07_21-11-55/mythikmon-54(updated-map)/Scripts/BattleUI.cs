#nullable enable
using Godot;
using System;
using System.Threading.Tasks;

namespace Mythikmon;

public partial class BattleUI : CanvasLayer
{
	[Signal] public delegate void AttackPressedEventHandler();
	[Signal] public delegate void TalismanPressedEventHandler();
	[Signal] public delegate void RunPressedEventHandler();

	// Optional: drag a battle background image here in the Inspector. Leave empty for the built-in grass field.
	[Export] public Texture2D? BackgroundTexture { get; set; }

	private Label enemyName = null!, playerName = null!, playerHpText = null!;
	private ProgressBar enemyHp = null!, playerHp = null!;
	private TextureRect enemySprite = null!, playerSprite = null!;
	private RichTextLabel message = null!;
	private Button talismanButton = null!;
	private Button[] menu = null!;
	private string[] menuLabels = { "ATTACK", "TALISMAN", "RUN" };
	private int cursor;

	// animated battle sprites (they replace the static TextureRects at runtime)
	private CreatureSprite enemyAnim = null!, playerAnim = null!;
	private Creature? shownEnemy, shownMine;   // which creature each sprite is currently set up for

	public override void _Ready()
	{
		enemyName = GetNode<Label>("%EnemyName");
		enemyHp = GetNode<ProgressBar>("%EnemyHp");
		enemySprite = GetNode<TextureRect>("%EnemySprite");
		playerName = GetNode<Label>("%PlayerName");
		playerHp = GetNode<ProgressBar>("%PlayerHp");
		playerHpText = GetNode<Label>("%PlayerHpText");
		playerSprite = GetNode<TextureRect>("%PlayerSprite");
		message = GetNode<RichTextLabel>("%Message");
		talismanButton = GetNode<Button>("%TalismanButton");

		var attackButton = GetNode<Button>("%AttackButton");
		var runButton = GetNode<Button>("%RunButton");
		menu = new[] { attackButton, talismanButton, runButton };

		attackButton.Pressed += () => EmitSignal(SignalName.AttackPressed);
		talismanButton.Pressed += () => EmitSignal(SignalName.TalismanPressed);
		runButton.Pressed += () => EmitSignal(SignalName.RunPressed);

		for (int i = 0; i < menu.Length; i++)
		{
			int idx = i;
			menu[i].MouseEntered += () => { cursor = idx; UpdateMenu(); };
		}
		// Hide the old static sprites and create the animated ones behind the UI panels.
		enemySprite.Visible = false;
		playerSprite.Visible = false;
		var root = GetNode<Control>("Root");

		// Home = where the creature's feet touch the ground. Tweak these to move/resize them.
		enemyAnim = new CreatureSprite { Zoom = 0.40f, Home = new Vector2(720, 240), FacesLeft = true, BreathTime = 1.0f };
		playerAnim = new CreatureSprite { Zoom = 0.50f, Home = new Vector2(215, 380), FacesLeft = false, BreathTime = 0.8f };
		root.AddChild(enemyAnim);
		root.AddChild(playerAnim);
		root.MoveChild(enemyAnim, 0);    // draw behind the HP panels and the bottom bar
		root.MoveChild(playerAnim, 0);

		// Battle backdrop, drawn behind everything else (hides the map).
		var bg = new BattleBackground
		{
			Texture = BackgroundTexture,
			EnemyHome = enemyAnim.Home,
			PlayerHome = playerAnim.Home
		};
		root.AddChild(bg);
		root.MoveChild(bg, 0);

		UpdateMenu();
	}

	// Arrow keys move the cursor, Enter/Space/Z confirm. Keys 1/2/3 are still handled in Game.cs.
	public override void _UnhandledInput(InputEvent e)
	{
		if (!Visible || e is not InputEventKey key || !key.Pressed || key.Echo) return;

		// 2x2 grid: slots 0 1 / 2 (3 is empty)
		int col = cursor % 2, row = cursor / 2;
		switch (key.Keycode)
		{
			case Key.Left:  col = 0; break;
			case Key.Right: col = 1; break;
			case Key.Up:    row = 0; break;
			case Key.Down:  row = 1; break;
			case Key.Enter:
			case Key.KpEnter:
			case Key.Space:
			case Key.Z:
				menu[cursor].EmitSignal(BaseButton.SignalName.Pressed);
				GetViewport().SetInputAsHandled();
				return;
			default: return;
		}
		int next = row * 2 + col;
		if (next < menu.Length) cursor = next;
		UpdateMenu();
		GetViewport().SetInputAsHandled();
	}

	private void UpdateMenu()
	{
		for (int i = 0; i < menu.Length; i++)
			menu[i].Text = (i == cursor ? "\u25B6 " : "    ") + menuLabels[i];
	}
	
	public void SetActive(bool active)
	{
		Visible = active;
		GetNode<Control>("Root").Visible = active;
	}

	public void Refresh(Creature? enemy, Texture2D? enemyTex, Creature? mine, Texture2D? myTex,
						string text, int talismans, bool animate)
	{
		if (enemy != null)
		{
			enemyName.Text = $"{enemy.Name}  Lv.{enemy.Level}".ToUpper();
			SetBar(enemyHp, enemy.HP, enemy.MaxHP, animate);
			// only (re)start the animation when the creature actually changed, not on every refresh
			if (!ReferenceEquals(enemy, shownEnemy)) { shownEnemy = enemy; enemyAnim.Setup(enemy); }
		}
		enemyAnim.Visible = enemy != null;

		if (mine != null)
		{
			playerName.Text = $"{mine.Name}  Lv.{mine.Level}".ToUpper();
			playerHpText.Text = $"HP: {mine.HP} / {mine.MaxHP}";
			SetBar(playerHp, mine.HP, mine.MaxHP, animate);
			if (!ReferenceEquals(mine, shownMine)) { shownMine = mine; playerAnim.Setup(mine); }
		}

		message.Text = text;
		menuLabels[1] = $"TALISMAN ({talismans})";
		UpdateMenu();
	}

	// Battle intro: iris closes to black -> prepare() runs while the screen is black -> iris opens ->
	// enemy slides in from the left and the player from the right -> enemy panel slides in from the
	// left and the player panel from the right.
	public async Task PlayIntroAsync(Action prepare)
	{
		var iris = new ScreenIris();
		GetTree().Root.AddChild(iris);

		await iris.CloseAsync(0.6);
		await ToSignal(GetTree().CreateTimer(0.15), SceneTreeTimer.SignalName.Timeout);

		prepare(); // shows the battle screen while everything is hidden behind the black

		float viewW = GetViewport().GetVisibleRect().Size.X;
		var enemyPanel = GetNode<Control>("Root/EnemyPanel");
		var playerPanel = GetNode<Control>("Root/PlayerPanel");

		float enemyPanelX = enemyPanel.Position.X;
		float playerPanelX = playerPanel.Position.X;

		// move everything off-screen first
		enemyAnim.Position = new Vector2(-260f, enemyAnim.Home.Y);
		playerAnim.Position = new Vector2(viewW + 260f, playerAnim.Home.Y);
		enemyPanel.Position = new Vector2(-enemyPanel.Size.X - 20f, enemyPanel.Position.Y);
		playerPanel.Position = new Vector2(viewW + 20f, playerPanel.Position.Y);

		await iris.OpenAsync(0.6);
		iris.QueueFree();

		// 1) creatures slide in
		var slide = CreateTween().SetParallel(true);
		slide.TweenProperty(enemyAnim, "position:x", enemyAnim.Home.X, 0.7)
			.SetTrans(Tween.TransitionType.Cubic).SetEase(Tween.EaseType.Out);
		slide.TweenProperty(playerAnim, "position:x", playerAnim.Home.X, 0.7)
			.SetTrans(Tween.TransitionType.Cubic).SetEase(Tween.EaseType.Out);
		await ToSignal(slide, Tween.SignalName.Finished);

		// 2) info panels slide in
		var panels = CreateTween().SetParallel(true);
		panels.TweenProperty(enemyPanel, "position:x", enemyPanelX, 0.45)
			.SetTrans(Tween.TransitionType.Cubic).SetEase(Tween.EaseType.Out);
		panels.TweenProperty(playerPanel, "position:x", playerPanelX, 0.45)
			.SetTrans(Tween.TransitionType.Cubic).SetEase(Tween.EaseType.Out);
		await ToSignal(panels, Tween.SignalName.Finished);
	}

	// Battle outro: iris closes to black -> atBlack() runs (hide the battle screen) -> iris opens
	// onto the map.
	public async Task PlayOutroAsync(Action atBlack)
	{
		var iris = new ScreenIris();
		GetTree().Root.AddChild(iris);

		await iris.CloseAsync(0.6);
		atBlack();
		await ToSignal(GetTree().CreateTimer(0.15), SceneTreeTimer.SignalName.Timeout);

		await iris.OpenAsync(0.6);
		iris.QueueFree();
	}

	// Call at the start of every battle so both sprites reset to idle (even if it is the same creature).
	public void BeginBattle()
	{
		shownEnemy = null;
		shownMine = null;
	}

	// The attacker lunges; when the hit lands onHit() runs (apply damage / update bars there)
	// and the defender plays Hurt, or Hurt -> Faint if defenderFaints is true.
	public async Task PlayAttackAsync(bool playerAttacks, Action onHit, bool defenderFaints)
	{
		var attacker = playerAttacks ? playerAnim : enemyAnim;
		var defender = playerAttacks ? enemyAnim : playerAnim;
		float dir = playerAttacks ? 1f : -1f;      // player is on the left, enemy on the right

		Task? hurt = null;
		await attacker.PlayAttackAsync(dir, () =>
		{
			onHit();
			hurt = defender.PlayHurtAsync(dir, defenderFaints);   // runs while the attacker returns
		});
		if (hurt != null) await hurt;
	}

	private void SetBar(ProgressBar bar, int hp, int max, bool animate)
	{
		bar.MaxValue = max;
		if (animate) CreateTween().TweenProperty(bar, "value", hp, 0.4);
		else bar.Value = hp;
	}
}
