#nullable enable
using Godot;
using System.Threading.Tasks;

namespace Mythikmon;

// Full-screen black "iris" wipe. Create it, add it to the tree, then await CloseAsync() / OpenAsync().
// CloseAsync: the visible circle shrinks to nothing (screen goes black).
// OpenAsync:  the circle grows again until the whole screen is visible.
public partial class ScreenIris : CanvasLayer
{
	private const string ShaderCode = @"
shader_type canvas_item;
uniform float radius = 0.0;
uniform vec2 center = vec2(480.0, 270.0);
uniform vec2 view_size = vec2(960.0, 540.0);
void fragment() {
	vec2 p = UV * view_size;
	float d = distance(p, center);
	COLOR = vec4(0.0, 0.0, 0.0, step(radius, d));
}";

	private readonly ShaderMaterial material = new();
	private float maxRadius;

	public override void _Ready()
	{
		Layer = 100; // above the map and the battle UI

		Vector2 size = GetViewport().GetVisibleRect().Size;
		maxRadius = size.Length() / 2f + 4f;

		material.Shader = new Shader { Code = ShaderCode };
		material.SetShaderParameter("view_size", size);
		material.SetShaderParameter("center", size / 2f);
		SetRadius(maxRadius); // starts fully open (invisible)

		AddChild(new ColorRect
		{
			Size = size,
			Color = Colors.White,
			Material = material,
			MouseFilter = Control.MouseFilterEnum.Ignore
		});
	}

	private void SetRadius(float r) => material.SetShaderParameter("radius", r);

	public Task CloseAsync(double seconds) => Animate(maxRadius, 0f, seconds);

	public Task OpenAsync(double seconds) => Animate(0f, maxRadius, seconds);

	private async Task Animate(float from, float to, double seconds)
	{
		var tween = CreateTween();
		tween.TweenMethod(Callable.From<float>(SetRadius), from, to, seconds)
			.SetTrans(Tween.TransitionType.Sine)
			.SetEase(Tween.EaseType.InOut);
		await ToSignal(tween, Tween.SignalName.Finished);
	}
}
