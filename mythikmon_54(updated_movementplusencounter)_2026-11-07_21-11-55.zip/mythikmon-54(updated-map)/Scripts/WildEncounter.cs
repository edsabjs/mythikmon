
#nullable enable
using Godot;

namespace Mythikmon;

public partial class WildEncounter : Area2D
{
	[Export] public BattleManager? Manager { get; set; }

	[Export] public string CreatureName { get; set; } = "Random";

	[Export] public bool RemoveAfterWin { get; set; } = false;

	// Encounter settings
	[Export(PropertyHint.Range, "1,100,1")]
	public int EncounterChance { get; set; } = 15;

	[Export(PropertyHint.Range, "8,128,1")]
	public float PixelsPerCheck { get; set; } = 32f;

	private bool playerInside = false;
	private bool wasInBattle = false;

	private Vector2 lastPosition;
	private float distanceWalked = 0f;
	private float cooldown = 0f;

	public override void _Ready()
	{
		BodyEntered += OnBodyEntered;
		BodyExited += OnBodyExited;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (Manager == null || body != Manager.PlayerCharacter)
			return;

		playerInside = true;
		lastPosition = body.GlobalPosition;
		distanceWalked = 0f;
	}

	private void OnBodyExited(Node2D body)
	{
		if (Manager == null || body != Manager.PlayerCharacter)
			return;

		playerInside = false;
		distanceWalked = 0f;
	}

	public override void _PhysicsProcess(double delta)
	{
		if (Manager?.PlayerCharacter == null)
			return;

		var player = Manager.PlayerCharacter;

		// Don't trigger encounters during battle.
		if (Manager.IsInBattle)
		{
			wasInBattle = true;
			lastPosition = player.GlobalPosition;
			return;
		}

		// Short cooldown after a battle ends.
		if (wasInBattle)
		{
			wasInBattle = false;
			cooldown = 2f;
			distanceWalked = 0f;
			lastPosition = player.GlobalPosition;
		}

		if (!playerInside)
			return;

		float moved = player.GlobalPosition.DistanceTo(lastPosition);
		lastPosition = player.GlobalPosition;

		if (cooldown > 0f)
		{
			cooldown = Mathf.Max(0f, cooldown - (float)delta);
			return;
		}

		// Count how far the player actually walks.
		distanceWalked += moved;

		if (distanceWalked >= PixelsPerCheck)
		{
			distanceWalked -= PixelsPerCheck;

			// Random encounter chance.
			if (GD.Randf() * 100f < EncounterChance)
			{
				distanceWalked = 0f;
				Manager.StartEncounter(this);
			}
		}
	}
}
