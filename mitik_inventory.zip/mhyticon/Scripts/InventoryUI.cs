#nullable enable
using Godot;
using System;
using System.Collections.Generic;

namespace Mythikmon;

// Pokemon-inspired pocket inventory for your existing Mythikmon map.
// Attach to your EXISTING InventoryUI (CanvasLayer).
// It builds its own layout in code; no extra UI nodes or image assets required.
public partial class InventoryUI : CanvasLayer
{
	[Export] public InventoryManager? InventoryManagerNode { get; set; }
	[Export] public CharacterBody2D? PlayerCharacter { get; set; }
	[Export] public CanvasLayer? BattleUiNode { get; set; }

	private enum Pocket { All, Talismans, Medicine, KeyItems }

	private static readonly (string Name, Pocket Pocket, string Description)[] Items =
	{
		(InventoryManager.Talisman, Pocket.Talismans,
			"A magical seal used to capture wild Mythikmon. Use it during a battle."),
		(InventoryManager.HealingHerb, Pocket.Medicine,
			"A healing herb. Healing a party creature with it can be added later."),
		(InventoryManager.AncientRelic, Pocket.KeyItems,
			"An ancient artifact connected to the mysteries of the region.")
	};

	private static readonly Color Ink = new("#2D3C3B");
	private static readonly Color Cream = new("#FFF6DA");
	private static readonly Color Muted = new("#D6E6D7");
	private static readonly Color Gold = new("#F3C96A");

	private Control overlay = null!;
	private VBoxContainer itemList = null!;
	private Label pocketTitle = null!;
	private Label detailTitle = null!;
	private Label detailText = null!;
	private Label itemCount = null!;

	private readonly Dictionary<Pocket, Button> pocketButtons = new();
	private readonly Dictionary<string, Button> itemButtons = new();
	private Pocket activePocket = Pocket.All;
	private string selectedItem = InventoryManager.Talisman;
	private bool isOpen = false;
	private bool playerWasMoving = false;

	public override void _Ready()
	{
		// Hide the old temporary label-based Panel from your existing scene.
		// Its nodes can stay in the Scene Tree for now.
		GetNodeOrNull<Control>("Panel")?.Hide();

		BuildBag();
		overlay.Hide(); // The bag must NEVER start open.

		if (InventoryManagerNode != null)
			InventoryManagerNode.ItemsChanged += RefreshContents;
		else
			GD.PushWarning("InventoryUI: Assign InventoryManager in the Inspector.");
	}

	public override void _ExitTree()
	{
		if (InventoryManagerNode != null && GodotObject.IsInstanceValid(InventoryManagerNode))
			InventoryManagerNode.ItemsChanged -= RefreshContents;
	}

	// _Input receives M even when a Button or other GUI control has focus.
	public override void _Input(InputEvent @event)
	{
		if (@event is not InputEventKey key || !key.Pressed || key.Echo)
			return;

		if (key.Keycode == Key.M)
		{
			if (isOpen) CloseBag();
			else OpenBag();
			GetViewport().SetInputAsHandled();
		}
		else if (key.Keycode == Key.Escape && isOpen)
		{
			CloseBag();
			GetViewport().SetInputAsHandled();
		}
	}

	private void OpenBag()
	{
		// Don't open your Bag over the existing battle screen.
		if (BattleUiNode != null && BattleUiNode.Visible)
			return;

		if (isOpen) return;
		isOpen = true;
		RefreshContents();
		overlay.Show();

		if (PlayerCharacter != null)
		{
			playerWasMoving = PlayerCharacter.IsPhysicsProcessing();
			PlayerCharacter.Velocity = Vector2.Zero;
			PlayerCharacter.SetPhysicsProcess(false);
		}
	}

	private void CloseBag()
	{
		if (!isOpen) return;
		isOpen = false;
		overlay.Hide();

		// Only restore physics if it was running before the Bag was opened.
		if (PlayerCharacter != null && GodotObject.IsInstanceValid(PlayerCharacter)
			&& playerWasMoving && (BattleUiNode == null || !BattleUiNode.Visible))
			PlayerCharacter.SetPhysicsProcess(true);

		playerWasMoving = false;
	}

	private void BuildBag()
	{
		overlay = new Control { Name = "BagOverlay", MouseFilter = Control.MouseFilterEnum.Stop };
		AddChild(overlay);
		overlay.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

		var dim = new ColorRect { Color = new Color(0f, 0f, 0f, 0.60f) };
		overlay.AddChild(dim);
		dim.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

		var bagFrame = new PanelContainer { Name = "BagWindow", MouseFilter = Control.MouseFilterEnum.Stop };
		overlay.AddChild(bagFrame);
		// Fits different game sizes while staying centered.
		bagFrame.AnchorLeft = 0.07f;
		bagFrame.AnchorTop = 0.08f;
		bagFrame.AnchorRight = 0.93f;
		bagFrame.AnchorBottom = 0.92f;
		bagFrame.OffsetLeft = 0;
		bagFrame.OffsetTop = 0;
		bagFrame.OffsetRight = 0;
		bagFrame.OffsetBottom = 0;
		bagFrame.AddThemeStyleboxOverride("panel", Box("#E6C886", "#314B45", 4, 9));

		var padding = new MarginContainer();
		padding.AddThemeConstantOverride("margin_left", 14);
		padding.AddThemeConstantOverride("margin_right", 14);
		padding.AddThemeConstantOverride("margin_top", 12);
		padding.AddThemeConstantOverride("margin_bottom", 12);
		bagFrame.AddChild(padding);

		var root = new VBoxContainer();
		root.AddThemeConstantOverride("separation", 9);
		padding.AddChild(root);

		var heading = new HBoxContainer();
		heading.AddThemeConstantOverride("separation", 8);
		root.AddChild(heading);
		heading.AddChild(Text("MYTHIKMON  /  BAG", 25, Ink, true));
		heading.AddChild(new Control { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill });
		heading.AddChild(Text("M = CLOSE", 13, Ink));
		var x = StyledButton("X", "#B85B4E", "#FAE1C6", 40);
		x.CustomMinimumSize = new Vector2(40, 34);
		x.Pressed += CloseBag;
		heading.AddChild(x);

		var columns = new HBoxContainer { SizeFlagsVertical = Control.SizeFlags.ExpandFill };
		columns.AddThemeConstantOverride("separation", 12);
		root.AddChild(columns);

		// LEFT: bag pockets (similar to a Pokemon bag's section selector).
		var pocketPanel = new PanelContainer { CustomMinimumSize = new Vector2(170, 0) };
		pocketPanel.AddThemeStyleboxOverride("panel", Box("#527767", "#29453D", 3, 8));
		columns.AddChild(pocketPanel);
		var pocketMargin = new MarginContainer();
		SetMargins(pocketMargin, 12);
		pocketPanel.AddChild(pocketMargin);
		var pockets = new VBoxContainer();
		pockets.AddThemeConstantOverride("separation", 8);
		pocketMargin.AddChild(pockets);
		pockets.AddChild(Text("POCKETS", 18, Cream, true));
		AddPocketButton(pockets, Pocket.All, "ALL ITEMS");
		AddPocketButton(pockets, Pocket.Talismans, "TALISMANS");
		AddPocketButton(pockets, Pocket.Medicine, "MEDICINE");
		AddPocketButton(pockets, Pocket.KeyItems, "KEY ITEMS");
		pockets.AddChild(new Control { SizeFlagsVertical = Control.SizeFlags.ExpandFill });
		pockets.AddChild(Text("Choose a pocket", 12, Muted));

		// RIGHT: selectable item list, item descriptions, close button.
		var rightPanel = new PanelContainer
		{
			SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
			SizeFlagsVertical = Control.SizeFlags.ExpandFill
		};
		rightPanel.AddThemeStyleboxOverride("panel", Box("#FFF5D8", "#9C865E", 3, 8));
		columns.AddChild(rightPanel);
		var rightMargin = new MarginContainer();
		SetMargins(rightMargin, 12);
		rightPanel.AddChild(rightMargin);
		var right = new VBoxContainer();
		right.AddThemeConstantOverride("separation", 8);
		rightMargin.AddChild(right);

		pocketTitle = Text("ALL ITEMS", 19, Ink, true);
		right.AddChild(pocketTitle);
		var listScroll = new ScrollContainer
		{
			SizeFlagsVertical = Control.SizeFlags.ExpandFill,
			HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled
		};
		right.AddChild(listScroll);
		itemList = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
		itemList.AddThemeConstantOverride("separation", 5);
		listScroll.AddChild(itemList);

		var infoPanel = new PanelContainer { CustomMinimumSize = new Vector2(0, 95) };
		infoPanel.AddThemeStyleboxOverride("panel", Box("#E7DFBB", "#AC9B6B", 2, 5));
		right.AddChild(infoPanel);
		var infoMargin = new MarginContainer();
		SetMargins(infoMargin, 8);
		infoPanel.AddChild(infoMargin);
		var info = new VBoxContainer();
		info.AddThemeConstantOverride("separation", 2);
		infoMargin.AddChild(info);
		var infoHeader = new HBoxContainer();
		info.AddChild(infoHeader);
		detailTitle = Text("", 16, Ink, true);
		infoHeader.AddChild(detailTitle);
		infoHeader.AddChild(new Control { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill });
		itemCount = Text("", 15, Ink, true);
		infoHeader.AddChild(itemCount);
		detailText = Text("", 13, Ink);
		detailText.AutowrapMode = TextServer.AutowrapMode.WordSmart;
		info.AddChild(detailText);

		var footer = new HBoxContainer();
		footer.AddThemeConstantOverride("separation", 8);
		right.AddChild(footer);
		footer.AddChild(Text("SELECT AN ITEM TO VIEW DETAILS", 12, Ink));
		footer.AddChild(new Control { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill });
		var close = StyledButton("CLOSE BAG", "#B85B4E", "#FFF8E5", 115);
		close.Pressed += CloseBag;
		footer.AddChild(close);
	}

	private void AddPocketButton(VBoxContainer parent, Pocket pocket, string label)
	{
		var button = StyledButton(label, "#345748", "#FFF8DC", 142);
		button.CustomMinimumSize = new Vector2(0, 42);
		button.Alignment = HorizontalAlignment.Left;
		button.Pressed += () => SelectPocket(pocket);
		parent.AddChild(button);
		pocketButtons[pocket] = button;
	}

	private void SelectPocket(Pocket pocket)
	{
		activePocket = pocket;
		RefreshContents();
	}

	private void RefreshContents()
	{
		if (itemList == null) return;

		pocketTitle.Text = activePocket switch
		{
			Pocket.Talismans => "	TALISMANS",
			Pocket.Medicine => "	MEDICINE",
			Pocket.KeyItems => "	KEY ITEMS",
			_ => "	ALL ITEMS"
		};

		foreach (var entry in pocketButtons)
			entry.Value.AddThemeStyleboxOverride("normal",
				Box(entry.Key == activePocket ? "#E4C974" : "#345748", "#243F37", 2, 5));

		foreach (Node child in itemList.GetChildren())
		{
			itemList.RemoveChild(child);
			child.QueueFree();
		}
		itemButtons.Clear();

		bool hasSelected = false;
		foreach (var item in Items)
		{
			if (activePocket != Pocket.All && item.Pocket != activePocket) continue;
			int count = InventoryManagerNode?.GetCount(item.Name) ?? 0;
			var row = StyledButton($"  {item.Name.ToUpper()}       x{count}",
				"#FAEBCB", "#283D37", 250);
			row.CustomMinimumSize = new Vector2(0, 42);
			row.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
			row.Alignment = HorizontalAlignment.Left;
			string chosenName = item.Name;
			row.Pressed += () => SelectItem(chosenName);
			itemList.AddChild(row);
			itemButtons[item.Name] = row;
			if (selectedItem == item.Name) hasSelected = true;
		}

		if (!hasSelected)
		{
			foreach (var item in Items)
			{
				if (activePocket == Pocket.All || item.Pocket == activePocket)
				{
					selectedItem = item.Name;
					break;
				}
			}
		}
		UpdateItemDetails();
	}

	private void SelectItem(string itemName)
	{
		selectedItem = itemName;
		UpdateItemDetails();
	}

	private void UpdateItemDetails()
	{
		foreach (var entry in itemButtons)
			entry.Value.AddThemeStyleboxOverride("normal",
				Box(entry.Key == selectedItem ? "#F2D780" : "#FAEBCB", "#9D865F", 2, 5));

		foreach (var item in Items)
		{
			if (item.Name != selectedItem) continue;
			detailTitle.Text = item.Name.ToUpper();
			itemCount.Text = $"x{InventoryManagerNode?.GetCount(item.Name) ?? 0}";
			detailText.Text = item.Description;
			break;
		}
	}

	private static Label Text(string value, int size, Color color, bool bold = false)
	{
		var label = new Label { Text = value };
		label.AddThemeColorOverride("font_color", color);
		label.AddThemeFontSizeOverride("font_size", size);
		if (bold) label.AddThemeColorOverride("font_shadow_color", new Color(0, 0, 0, 0.08f));
		return label;
	}

	private static Button StyledButton(string value, string background, string textColor, int minWidth)
	{
		var b = new Button
		{
			Text = value,
			CustomMinimumSize = new Vector2(minWidth, 36),
			FocusMode = Control.FocusModeEnum.None
		};
		b.AddThemeColorOverride("font_color", new Color(textColor));
		b.AddThemeColorOverride("font_hover_color", new Color(textColor));
		b.AddThemeColorOverride("font_pressed_color", new Color(textColor));
		b.AddThemeStyleboxOverride("normal", Box(background, "#8B7B5A", 2, 5));
		b.AddThemeStyleboxOverride("hover", Box("#F4D787", "#8B7B5A", 2, 5));
		b.AddThemeStyleboxOverride("pressed", Box("#DDB966", "#5F513A", 2, 5));
		return b;
	}

	private static StyleBoxFlat Box(string background, string border, int width, int radius)
	{
		var style = new StyleBoxFlat
		{
			BgColor = new Color(background),
			BorderColor = new Color(border),
			AntiAliasing = false
		};
		style.SetBorderWidthAll(width);
		style.SetCornerRadiusAll(radius);
		return style;
	}

	private static void SetMargins(MarginContainer m, int amount)
	{
		m.AddThemeConstantOverride("margin_left", amount);
		m.AddThemeConstantOverride("margin_right", amount);
		m.AddThemeConstantOverride("margin_top", amount);
		m.AddThemeConstantOverride("margin_bottom", amount);
	}
}
