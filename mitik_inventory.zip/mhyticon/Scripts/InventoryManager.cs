
#nullable enable
using Godot;
using System;
using System.Collections.Generic;
using System.Text.Json;

namespace Mythikmon;

public partial class InventoryManager : Node
{
	public const string Talisman = "Talisman";
	public const string HealingHerb = "Healing Herb";
	public const string AncientRelic = "Ancient Relic";

	private const string SavePath = "user://inventory_items.json";

	private Dictionary<string, int> items = new()
	{
		[HealingHerb] = 0,
		[AncientRelic] = 0
	};

	public event Action? ItemsChanged;

	public override void _Ready()
	{
		LoadInventory();
	}

	public int GetCount(string itemName)
	{
		if (itemName == Talisman)
			return PlayerData.Load().Talismans;

		return items.TryGetValue(itemName, out int count)
			? count : 0;
	}

	public void AddItem(string itemName, int amount = 1)
	{
		if (amount <= 0) return;

		if (itemName == Talisman)
		{
			var playerData = PlayerData.Load();
			playerData.Talismans += amount;
			playerData.Save();
		}
		else if (items.ContainsKey(itemName))
		{
			items[itemName] += amount;
			SaveInventory();
		}
		else
		{
			GD.PushWarning("Unknown item: " + itemName);
			return;
		}

		ItemsChanged?.Invoke();
	}

	public bool TryRemoveItem(string itemName, int amount = 1)
	{
		if (amount <= 0 || GetCount(itemName) < amount)
			return false;

		if (itemName == Talisman)
		{
			var playerData = PlayerData.Load();
			playerData.Talismans -= amount;
			playerData.Save();
		}
		else
		{
			items[itemName] -= amount;
			SaveInventory();
		}

		ItemsChanged?.Invoke();
		return true;
	}

	private void SaveInventory()
	{
		using var file = FileAccess.Open(
			SavePath, FileAccess.ModeFlags.Write);

		if (file != null)
			file.StoreString(JsonSerializer.Serialize(items));
	}

	private void LoadInventory()
	{
		if (!FileAccess.FileExists(SavePath))
			return;

		try
		{
			string text = FileAccess.GetFileAsString(SavePath);
			var saved = JsonSerializer.Deserialize<
				Dictionary<string, int>>(text);

			if (saved == null) return;

			foreach (string item in new[] { HealingHerb, AncientRelic })
			{
				if (saved.TryGetValue(item, out int count))
					items[item] = Mathf.Max(0, count);
			}
		}
		catch (Exception e)
		{
			GD.PushWarning("Inventory load failed: " + e.Message);
		}
	}
}
