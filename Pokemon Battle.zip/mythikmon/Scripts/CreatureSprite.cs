#nullable enable
using Godot;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mythikmon;

public enum CreaturePose { Idle, Attack, Hurt, Faint }

// Draws one creature in the battle scene and plays its Idle / Attack / Hurt / Faint animations.
// The node's origin is the creature's FEET, so every pose (they all have different image sizes)
// stands on the same spot on the ground no matter which texture is showing.
public partial class CreatureSprite : Node2D
{
	// texture + the rectangle of non-transparent pixels, cached so we only analyse each PNG once
	private static readonly Dictionary<string, (Texture2D Tex, Rect2I Used)> Cache = new();

	public float Zoom { get; set; } = 0.4f;           // all poses are drawn at the same scale
	public Vector2 Home { get; set; }                 // where the feet rest (in the parent's space)
	public float BreathTime { get; set; } = 0.9f;     // seconds for one breath in / out
	public bool FadeAfterFaint { get; set; } = true;  // fade out after lying on the ground for a moment
	public CreaturePose CurrentPose { get; private set; } = CreaturePose.Idle;

	// Source art faces right. The enemy faces left, so we mirror the whole node.
	public bool FacesLeft
	{
		get => Scale.X < 0;
		set => Scale = new Vector2(value ? -1f : 1f, 1f);
	}

	private readonly Node2D body = new();                       // breathing / landing animation
	private readonly Sprite2D sprite = new() { Centered = false };
	private Creature? creature;
	private Tween? idleTween;

	public override void _Ready()
	{
		AddChild(body);
		body.AddChild(sprite);
	}

	// Call this when a new creature enters the battle. Resets everything and starts the idle loop.
	public void Setup(Creature c)
	{
		creature = c;
		Position = Home;
		Modulate = Colors.White;
		body.Position = Vector2.Zero;
		Visible = true;
		SetPose(CreaturePose.Idle);
		StartIdle();
	}

	// ---------------------------------------------------------------- poses

	private void SetPose(CreaturePose pose)
	{
		CurrentPose = pose;
		if (creature == null) return;

		var (tex, used) = LoadPose(creature, pose);
		sprite.Texture = tex;
		sprite.Scale = new Vector2(Zoom, Zoom);

		// bottom-centre of the visible pixels -> becomes the node origin
		var feet = new Vector2(used.Position.X + used.Size.X / 2f, used.End.Y);
		sprite.Position = -feet * Zoom;
	}

	private static (Texture2D Tex, Rect2I Used) LoadPose(Creature c, CreaturePose pose)
	{
		string file = pose switch
		{
			CreaturePose.Idle => "Idle",
			CreaturePose.Attack => "Atk",
			CreaturePose.Hurt => "Hurt",
			_ => "Faint"
		};
		string path = $"res://Assets/{c.AnimPrefix}_{file}.png";

		if (Cache.TryGetValue(path, out var hit)) return hit;

		Texture2D tex;
		if (ResourceLoader.Exists(path)) tex = GD.Load<Texture2D>(path);
		else
		{
			GD.PushWarning($"Missing animation sprite: {path} (using static sprite instead)");
			tex = GD.Load<Texture2D>(c.SpritePath);
		}

		var used = tex.GetImage().GetUsedRect();
		if (used.Size == Vector2I.Zero) used = new Rect2I(0, 0, tex.GetWidth(), tex.GetHeight());

		Cache[path] = (tex, used);
		return Cache[path];
	}

	// ---------------------------------------------------------------- idle

	private void StartIdle()
	{
		idleTween?.Kill();
		body.Scale = Vector2.One;

		// gentle "breathing": stretch up from the feet, then settle back down
		idleTween = CreateTween().SetLoops();
		idleTween.TweenProperty(body, "scale", new Vector2(0.99f, 1.025f), BreathTime)
			.SetTrans(Tween.TransitionType.Sine).SetEase(Tween.EaseType.InOut);
		idleTween.TweenProperty(body, "scale", Vector2.One, BreathTime)
			.SetTrans(Tween.TransitionType.Sine).SetEase(Tween.EaseType.InOut);
	}

	private void StopIdle()
	{
		idleTween?.Kill();
		idleTween = null;
		body.Scale = Vector2.One;
	}

	// ---------------------------------------------------------------- attack

	// dir = +1 if the target is to the right of this creature, -1 if to the left.
	// onHit is called at the exact moment the attack connects.
	public async Task PlayAttackAsync(float dir, Action onHit)
	{
		StopIdle();

		var t = CreateTween();
		// wind-up: lean back a little (still the idle pose)
		t.TweenProperty(this, "position:x", Home.X - dir * 14f, 0.10)
			.SetTrans(Tween.TransitionType.Sine).SetEase(Tween.EaseType.Out);
		// switch to the attack pose and lunge forward
		t.TweenCallback(Callable.From(() => SetPose(CreaturePose.Attack)));
		t.TweenProperty(this, "position:x", Home.X + dir * 70f, 0.10)
			.SetTrans(Tween.TransitionType.Quad).SetEase(Tween.EaseType.In);
		// impact
		t.TweenCallback(Callable.From(onHit));
		t.TweenInterval(0.20);
		// return to position
		t.TweenProperty(this, "position:x", Home.X, 0.20)
			.SetTrans(Tween.TransitionType.Sine).SetEase(Tween.EaseType.InOut);

		await ToSignal(t, Tween.SignalName.Finished);

		SetPose(CreaturePose.Idle);
		StartIdle();
	}

	// ---------------------------------------------------------------- hurt / faint

	// knockDir = direction the creature is pushed (+1 right, -1 left).
	// If faint is true the creature plays the faint animation after the hit reaction.
	public async Task PlayHurtAsync(float knockDir, bool faint)
	{
		StopIdle();
		SetPose(CreaturePose.Hurt);
		Modulate = new Color(1f, 0.55f, 0.55f);   // red tint

		var t = CreateTween();
		t.TweenProperty(this, "position:x", Home.X + knockDir * 16f, 0.06);
		for (int i = 0; i < 3; i++)                // classic blink
		{
			t.TweenProperty(this, "modulate:a", 0.15f, 0.05);
			t.TweenProperty(this, "modulate:a", 1.0f, 0.05);
		}
		t.TweenProperty(this, "position:x", Home.X, 0.10);
		await ToSignal(t, Tween.SignalName.Finished);

		Modulate = Colors.White;

		if (!faint)
		{
			SetPose(CreaturePose.Idle);
			StartIdle();
			return;
		}

		// faint: drop to the ground with a little bounce, stay down, then fade away
		SetPose(CreaturePose.Faint);
		body.Position = new Vector2(0f, -30f);

		var f = CreateTween();
		f.TweenProperty(body, "position:y", 0f, 0.40)
			.SetTrans(Tween.TransitionType.Bounce).SetEase(Tween.EaseType.Out);
		if (FadeAfterFaint)
		{
			f.TweenInterval(0.50);
			f.TweenProperty(this, "modulate:a", 0f, 0.60);
		}
		await ToSignal(f, Tween.SignalName.Finished);
	}
}
