using Godot;

public partial class Player : CharacterBody2D
{
	[Export]
	public float Speed = 150f;

	private AnimatedSprite2D animatedSprite;

	public override void _Ready()
	{
		animatedSprite = GetNode<AnimatedSprite2D>(
            "AnimatedSprite2D"
		);
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 direction = Input.GetVector(
			"move_left",
			"move_right",
			"move_up",
            "move_down"
		);

		Velocity = direction * Speed;
		MoveAndSlide();

		// Play walking animation
		if (direction != Vector2.Zero)
		{
			if (Mathf.Abs(direction.X) >
				Mathf.Abs(direction.Y))
			{
				if (direction.X > 0)
					PlayAnimation("walk_right");
				else
					PlayAnimation("walk_left");
			}
			else
			{
				if (direction.Y > 0)
					PlayAnimation("walk_down");
				else
					PlayAnimation("walk_up");
			}
		}
		else
		{
			// Stop animation when not moving
			animatedSprite.Stop();
			animatedSprite.Frame = 0;
		}
	}

	private void PlayAnimation(string animation)
	{
		if (animatedSprite.SpriteFrames.HasAnimation(animation)
			&& animatedSprite.SpriteFrames.GetFrameCount(animation) > 0)
		{
			animatedSprite.Play(animation);
		}
	}
}
