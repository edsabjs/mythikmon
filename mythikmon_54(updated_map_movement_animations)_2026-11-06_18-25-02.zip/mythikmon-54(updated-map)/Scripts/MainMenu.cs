using Godot;
using System;

public partial class MainMenu : Control
{
	public override void _Ready()
	{
		GetNode<Button>("Continue").Pressed += OnContinuePressed;
		GetNode<Button>("NewGame").Pressed += OnNewGamePressed;
		GetNode<Button>("Exit").Pressed += OnExitPressed;

		// Keyboard navigation
		GetNode<Button>("NewGame").GrabFocus();
	}

	private void OnContinuePressed()
	{
		GoToScene("res://Scenes/entire_map3.tscn");
	}

	private void OnNewGamePressed()
	{
		GoToScene("res://Scenes/entire_map3.tscn");
	}

	private void OnExitPressed()
	{
		GetTree().Quit();
	}

	private void GoToScene(string path)
	{
		if (ResourceLoader.Exists(path))
			GetTree().ChangeSceneToFile(path);
		else
			GD.PrintErr($"Scene not found: {path}");
	}
}
